python3 -m tensorboard.main --logdir ../logs/tb
